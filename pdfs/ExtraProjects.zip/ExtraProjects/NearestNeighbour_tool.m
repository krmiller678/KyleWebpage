function NearestNeighbour_tool(hGUI)

%--------------------------------------------------------------------------
%                              Main Function
%--------------------------------------------------------------------------

    % Initialize GUI document variables
    GUI.selected_region1 = 1;
    GUI.TotalAreaMatrix = zeros(0,2);
    GUI.selected_region2 = 1;
    GUI.Button3passed = 0;
    GUI.Dmap = struct('modelid',{[0 0]},'regionid',{[0 0]},'nnid',{[]},'nnid2',{[]},'d1',{[]},'d2',{[]},'dmin',{[]},'closestpt',{[]},'contactpt',{[]},'color1',{[]},'color2',{[]},'cutoff',{10},'contact',{10});
    
    % Disply GUI to screen
    init_display();
    
%--------------------------------------------------------------------------
%                         GUI Objects and Layout
%--------------------------------------------------------------------------

    function init_display()

%         GUI.hFigure = figure('MenuBar','none',...
%                              'Toolbar','none',...
%                              'Name','Region Select Tool',...
%                              'NumberTitle','off',...
%                              'Resize','off',...
%                              'Position',[hGUI.scrnsz(3)/2-350 hGUI.scrnsz(4)/2-80 350 160]);


        % Region select options figure                
        GUI.hFigure1 = figure('MenuBar','none',...
                             'Toolbar','none',...
                             'Name','Nearest Neighbour Options',...
                             'Color','w',...
                             'NumberTitle','off',...
                             'Resize','off',...
                             ...%'ResizeFcn',@hFigure2_resize,...
                             'Position',[hGUI.scrnsz(3)/2-175 hGUI.scrnsz(4)/2-hGUI.scrnsz(4)/4 350 hGUI.scrnsz(4)/2],...
                             'Renderer','OpenGL',...
                             'Visible','on');

            GUI.hPanel1 = uipanel('Parent',GUI.hFigure1,...
                                  'Units','pixels',...
                                  'Position',[0 0 350 hGUI.scrnsz(4)/2],...
                                  'BackgroundColor',[232/256 232/256 232/256],...
                                  'BorderType','none');

            GUI.hButton1 = uicontrol(GUI.hPanel1,...
                                     'Style', 'pushbutton',...
                                     'String','Cancel',...
                                     'Callback',@UI_Button1,...
                                     'Position',[185 10 75 30]);

            GUI.hButton2 = uicontrol(GUI.hPanel1,...
                                     'Style', 'pushbutton',...
                                     'String','Accept',...
                                     'Callback',@UI_Button2,...
                                     'Enable','on',...
                                     'Position',[265 10 75 30]);

            GUI.hPanel2 = uipanel('Parent',GUI.hPanel1,...
                                  'Title','Select Two Regions',...
                                  'Units','pixels',...
                                  'Position',[10 hGUI.scrnsz(4)/2-95 335 90],...
                                  ...%'ForegroundColor',[0/256 0/256 0/256],...
                                  ...%'HighlightColor',[0/256 0/256 0/256],...
                                  'BackgroundColor',[232/256 232/256 232/256],...
                                  'BorderType','etchedin');

                GUI.hPopupmenu1 = uicontrol('Parent',GUI.hPanel2,...
                                       'Style','popupmenu',...
                                       'Units','pixels',...
                                       'Position',[10 50 315 20],...
                                       'BackgroundColor','w',...
                                       'Callback',@UI_Popupmenu1,...
                                       'String','...');
                                   
                GUI.hPopupmenu2 = uicontrol('Parent',GUI.hPanel2,...
                                       'Style','popupmenu',...
                                       'Units','pixels',...
                                       'Position',[10 10 315 20],...
                                       'BackgroundColor','w',...
                                       'Callback',@UI_Popupmenu2,...
                                       'String','...');
                                   
            GUI.hPanel3 = uipanel('Parent',GUI.hPanel1,...
                                 'Title','Options',...
                                 'Units','pixels',...
                                 'Position',[10 50 335 hGUI.scrnsz(4)/2-150],...
                                 ...%'ForegroundColor',[0/256 0/256 0/256],...
                                 ...%'HighlightColor',[0/256 0/256 0/256],...
                                 'BackgroundColor',[232/256 232/256 232/256],...
                                 'BorderType','etchedin');
                             
                GUI.hText1 = uicontrol('Parent',GUI.hPanel3,...
                                       'Style','text',...
                                       'Units','pixels',...
                                       'Position',[10 hGUI.scrnsz(4)/2-187 152 12],...
                                       'BackgroundColor',[232/256 232/256 232/256],...
                                       'HorizontalAlignment','left',...
                                       'String','Horizontal Distance');
                             
                GUI.hEdit1 = uicontrol('Parent',GUI.hPanel3,...
                                       'Style','edit',...
                                       'Units','pixels',...
                                       'Position',[173 hGUI.scrnsz(4)/2-195 152 25],...
                                       'BackgroundColor','w',...
                                       'HorizontalAlignment','center',...
                                       'Callback',@UI_Edit1,...
                                       'String','10');
                                   
                GUI.hText2 = uicontrol('Parent',GUI.hPanel3,...
                                       'Style','text',...
                                       'Units','pixels',...
                                       'Position',[10 hGUI.scrnsz(4)/2-222 152 12],...
                                       'BackgroundColor',[232/256 232/256 232/256],...
                                       'HorizontalAlignment','left',...
                                       'String','Contact Cutoff');
                             
                GUI.hEdit2 = uicontrol('Parent',GUI.hPanel3,...
                                       'Style','edit',...
                                       'Units','pixels',...
                                       'Position',[173 hGUI.scrnsz(4)/2-230 152 25],...
                                       'BackgroundColor','w',...
                                       'HorizontalAlignment','center',...
                                       'Callback',@UI_Edit2,...
                                       'String','10');
                                   
                GUI.hText3 = uicontrol('Parent',GUI.hPanel3,...
                                       'Style','text',...
                                       'Units','pixels',...
                                       'Position',[10 hGUI.scrnsz(4)/2-257 152 12],...
                                       'BackgroundColor',[232/256 232/256 232/256],...
                                       'HorizontalAlignment','left',...
                                       'String','Radius FV');
                             
                GUI.hEdit3 = uicontrol('Parent',GUI.hPanel3,...
                                       'Style','edit',...
                                       'Units','pixels',...
                                       'Position',[173 hGUI.scrnsz(4)/2-265 152 25],...
                                       'BackgroundColor','w',...
                                       'HorizontalAlignment','center',...
                                       'Callback',@UI_Edit3,...
                                       'String','10');

                GUI.hText4 = uicontrol('Parent',GUI.hPanel3,...
                                       'Style','text',...
                                       'Units','pixels',...
                                       'Position',[10 hGUI.scrnsz(4)/2-292 152 12],...
                                       'BackgroundColor',[232/256 232/256 232/256],...
                                       'HorizontalAlignment','left',...
                                       'String','Contact Point X');
                             
                GUI.hEdit4 = uicontrol('Parent',GUI.hPanel3,...
                                       'Style','edit',...
                                       'Units','pixels',...
                                       'Position',[173 hGUI.scrnsz(4)/2-300 152 25],...
                                       'BackgroundColor','w',...
                                       'HorizontalAlignment','center',...
                                       'Callback',@UI_Edit4,...
                                       'String','10');
                                   
                GUI.hText5 = uicontrol('Parent',GUI.hPanel3,...
                                       'Style','text',...
                                       'Units','pixels',...
                                       'Position',[10 hGUI.scrnsz(4)/2-327 152 12],...
                                       'BackgroundColor',[232/256 232/256 232/256],...
                                       'HorizontalAlignment','left',...
                                       'String','Contact Point Y');
                             
                GUI.hEdit5 = uicontrol('Parent',GUI.hPanel3,...
                                       'Style','edit',...
                                       'Units','pixels',...
                                       'Position',[173 hGUI.scrnsz(4)/2-335 152 25],...
                                       'BackgroundColor','w',...
                                       'HorizontalAlignment','center',...
                                       'Callback',@UI_Edit5,...
                                       'String','10');
                                   
                GUI.hText6 = uicontrol('Parent',GUI.hPanel3,...
                                       'Style','text',...
                                       'Units','pixels',...
                                       'Position',[10 hGUI.scrnsz(4)/2-362 152 12],...
                                       'BackgroundColor',[232/256 232/256 232/256],...
                                       'HorizontalAlignment','left',...
                                       'String','Contact Point Z');
                             
                GUI.hEdit6 = uicontrol('Parent',GUI.hPanel3,...
                                       'Style','edit',...
                                       'Units','pixels',...
                                       'Position',[173 hGUI.scrnsz(4)/2-370 152 25],...
                                       'BackgroundColor','w',...
                                       'HorizontalAlignment','center',...
                                       'Callback',@UI_Edit6,...
                                       'String','10');
                                   
%             GUI.hPanel3 = uibuttongroup('Parent',GUI.hPanel1,...
%                                         'Title','Options',...
%                                         'SelectionChangeFcn',@UI_SelectionChange,...
%                                         'Units','pixels',...
%                                         'Position',[10 50 335 hGUI.scrnsz(4)/2-110],...
%                                         ...%'ForegroundColor',[0/256 0/256 0/256],...
%                                         ...%'HighlightColor',[0/256 0/256 0/256],...
%                                         'BackgroundColor',[232/256 232/256 232/256],...
%                                         'BorderType','etchedin');
%                          
%                 GUI.hButton3 = uicontrol(GUI.hPanel3,...
%                                          'Style', 'radiobutton',...
%                                          'Units','pixels',...
%                                          'String','Bounding Box Region',...
%                                          'Position',[10 hGUI.scrnsz(4)/2-150 200 20]);
%                                   
%                 GUI.hButton4 = uicontrol(GUI.hPanel3,...
%                                          'Style', 'radiobutton',...
%                                          'Units','pixels',...
%                                          'String','Custom Region',...
%                                          'Position',[10 hGUI.scrnsz(4)/2-280 200 20]);

        % Initialize other properties
        str = cell(1,length(hGUI.hRegion));
        for i = 1:length(hGUI.hRegion)
            str{i} = get(hGUI.hRegion{i},'Tag');
        end
        set(GUI.hPopupmenu1,'String',str)
        set(GUI.hPopupmenu2,'String',str)

        
        % Additional settings
        
        UI_Popupmenu1(GUI.hPopupmenu1,0)
        UI_Popupmenu2(GUI.hPopupmenu2,0)
        
        %UI_SelectionChange(GUI.hPanel3,0)
        
        drawnow;
    end
                         
    

%--------------------------------------------------------------------------
%                          UI Control Callbacks
%--------------------------------------------------------------------------

    % Cancel
    function UI_Button1(hObject,eventdata)
        close(GUI.hFigure1)
    end

    % Accept
    function UI_Button2(hObject,eventdata)
        
        % Performe nearest neighbour computation
        distancemap()
        
        % Save distance map to main gui
        hGUI.Dmap{length(hGUI.Dmap)+1}=GUI.Dmap;
        
        % Create closest point graphic objects
        %cp1 = hGUI.Region.v{hGUI.Dmap{length(hGUI.Dmap)}.regionid(1)}(hGUI.Dmap{length(hGUI.Dmap)}.closestpt{hGUI.frame}(1),1:3);
        %cp2 = hGUI.Region.v{hGUI.Dmap{length(hGUI.Dmap)}.regionid(2)}(hGUI.Dmap{length(hGUI.Dmap)}.closestpt{hGUI.frame}(2),1:3);
        
        %hGUI.hClosestpt{length(hGUI.hClosestpt)+1} = drawSphere(hGUI.Region.v{hGUI.Dmap{length(hGUI.Dmap)}.regionid(1)}(hGUI.Dmap{length(hGUI.Dmap)}.closestpt{hGUI.frame}(1),1),...
                                                           %hGUI.Region.v{hGUI.Dmap{length(hGUI.Dmap)}.regionid(1)}(hGUI.Dmap{length(hGUI.Dmap)}.closestpt{hGUI.frame}(1),2),...
                                                           %hGUI.Region.v{hGUI.Dmap{length(hGUI.Dmap)}.regionid(1)}(hGUI.Dmap{length(hGUI.Dmap)}.closestpt{hGUI.frame}(1),3),0.75,'FaceColor','b','EdgeColor','none');

        %hGUI.hClosestpt{length(hGUI.hClosestpt)} = copyobj(hGUI.hClosestpt{length(hGUI.hClosestpt)},hGUI.hTform{hGUI.Dmap{length(hGUI.Dmap)}.modelid(1)});
                                                       
        %hGUI.hClosestpt{length(hGUI.hClosestpt)+1} = drawSphere(hGUI.Region.v{hGUI.Dmap{length(hGUI.Dmap)}.regionid(2)}(hGUI.Dmap{length(hGUI.Dmap)}.closestpt{hGUI.frame}(2),1),...
                                                           %hGUI.Region.v{hGUI.Dmap{length(hGUI.Dmap)}.regionid(2)}(hGUI.Dmap{length(hGUI.Dmap)}.closestpt{hGUI.frame}(2),2),...
                                                           %hGUI.Region.v{hGUI.Dmap{length(hGUI.Dmap)}.regionid(2)}(hGUI.Dmap{length(hGUI.Dmap)}.closestpt{hGUI.frame}(2),3),0.75,'FaceColor','b','EdgeColor','none');
                                                       
        %hGUI.hClosestpt{length(hGUI.hClosestpt)} = copyobj(hGUI.hClosestpt{length(hGUI.hClosestpt)},hGUI.hTform{hGUI.Dmap{length(hGUI.Dmap)}.modelid(2)});
        
        % Create contact point graphic objects
        %cp3 = GUI.Dmap.contactpt{hGUI.frame}(1,1:3);
        %cp4 = GUI.Dmap.contactpt{hGUI.frame}(2,1:3);
        
        
        %hGUI.hContactpt{length(hGUI.hContactpt)+1} = drawSphere(GUI.Dmap.contactpt{hGUI.frame}(1,1),GUI.Dmap.contactpt{hGUI.frame}(1,2),GUI.Dmap.contactpt{hGUI.frame}(1,3),0.75,'FaceColor','m','EdgeColor','none');
        %hGUI.hContactpt{length(hGUI.hContactpt)} = copyobj(hGUI.hContactpt{length(hGUI.hContactpt)},hGUI.hTform{hGUI.Dmap{length(hGUI.Dmap)}.modelid(1)});
        
        %hGUI.hContactpt{length(hGUI.hContactpt)+1} = drawSphere(GUI.Dmap.contactpt{hGUI.frame}(2,1),GUI.Dmap.contactpt{hGUI.frame}(2,2),GUI.Dmap.contactpt{hGUI.frame}(2,3),0.75,'FaceColor','m','EdgeColor','none');
        %hGUI.hContactpt{length(hGUI.hContactpt)} = copyobj(hGUI.hContactpt{length(hGUI.hContactpt)},hGUI.hTform{hGUI.Dmap{length(hGUI.Dmap)}.modelid(2)});
        
        
        
        % Update gui data
        guidata(hGUI.hFigure,hGUI)
        close(GUI.hFigure1)
    end

    function UI_Popupmenu1(hObject,eventdata)
        GUI.selected_region1 = get(hObject,'Value');
    end

    function UI_Popupmenu2(hObject,eventdata)
        GUI.selected_region2 = get(hObject,'Value');
    end

    function UI_SelectionChange(hObject,eventdata)
        hobj = get(hObject,'SelectedObject');
        switch hobj
            case GUI.hButton3
                if GUI.region.patch{1} == 0
                    v = get(hGUI.hPatch{GUI.selected_model},'Vertices');
                    add_contact_box(v,GUI.hAxes)
                else
                    set(GUI.region.patch{1},'Visible','on')
                end
                GUI.Button3passed = 1;
                enable_accept();
            case GUI.hButton4
                set(GUI.region.patch{1},'Visible','off')
        end
    end

    function UI_Edit1(hObject,eventdata)
        GUI.Dmap.cutoff = str2num(get(hObject,'String'));
    end

    function UI_Edit2(hObject,eventdata)
        GUI.Dmap.contact = str2num(get(hObject,'String'));
    end

    function UI_Edit3(hObject,eventdata)
        GUI.Dmap.radius = str2num(get(hObject,'String'));
    end

    function UI_Edit4(hObject,eventdata)
        GUI.Dmap.contactpointx = str2num(get(hObject,'String'));
    end

    function UI_Edit5(hObject,eventdata)
        GUI.Dmap.contactpointy = str2num(get(hObject,'String'));
    end

    function UI_Edit6(hObject,eventdata)
        GUI.Dmap.contactpointz = str2num(get(hObject,'String'));
    end
%--------------------------------------------------------------------------
%                            Other Callbacks
%--------------------------------------------------------------------------



%--------------------------------------------------------------------------
%                              GUI Utilities
%--------------------------------------------------------------------------

    function enable_accept()
        if (GUI.Button3passed == 1)
            set(GUI.hButton2,'Enable','on') 
        else
            set(GUI.hButton2,'Enable','off')
        end
    end

    function distancemap()
    
        
        % Update statusbar
        % set(hGUI.hStatusbar,'String','Calculating nearest neighbor...'); drawnow;

        % Prepare homogeneous region vertex data
        V1 = [hGUI.Region.v{GUI.selected_region1}(:,1)'; hGUI.Region.v{GUI.selected_region1}(:,2)'; hGUI.Region.v{GUI.selected_region1}(:,3)'; ones(1,length(hGUI.Region.v{GUI.selected_region1}))];
        V2 = [hGUI.Region.v{GUI.selected_region2}(:,1)'; hGUI.Region.v{GUI.selected_region2}(:,2)'; hGUI.Region.v{GUI.selected_region2}(:,3)'; ones(1,length(hGUI.Region.v{GUI.selected_region2}))];

        % Prepare region Face data
        F1 = get(hGUI.hPatch{hGUI.Region.modelid{GUI.selected_region1}},'faces');
        F2 = get(hGUI.hPatch{hGUI.Region.modelid{GUI.selected_region2}},'faces');

        % Get transform sequences
        kindata1 = get(hGUI.hPatch{hGUI.Region.modelid{GUI.selected_region1}},'UserData');
        kindata2 = get(hGUI.hPatch{hGUI.Region.modelid{GUI.selected_region2}},'UserData');
        
        % Get model id
        GUI.Dmap.modelid(1) = hGUI.Region.modelid{GUI.selected_region1};
        GUI.Dmap.modelid(2) = hGUI.Region.modelid{GUI.selected_region2};
        
        % Get region id
        GUI.Dmap.regionid(1) = GUI.selected_region1;
        GUI.Dmap.regionid(2) = GUI.selected_region2;
        
        progressbar;
        
            
        %Set point of interest for FV method
        poi = [GUI.Dmap.contactpointx; GUI.Dmap.contactpointy; GUI.Dmap.contactpointz; 1];
        ooi = [0; 0; 0; 1];
        
        for frame = 1:hGUI.num_kin

            % Transform regions
            V1new = kindata1.tform{frame}*V1;
            V2new = kindata2.tform{frame}*V2;           
            
            % Find nearest neighbour
            Scalar = isempty(GUI.Dmap.radius); 
            if Scalar == 1
                GUI.Dmap.nnid1{frame} = nearestneighbour(V1new,V2new,'Delaunay','off');
                GUI.Dmap.nnid2{frame} = nearestneighbour(V2new,V1new,'Delaunay','off');
            elseif Scalar ~=1
                poiedit = kindata1.tform{frame} * poi;
                x = poiedit(1,1);
                y = poiedit(2,1);
                z = poiedit(3,1);
                
                ooiedit = kindata1.tform{frame} * ooi;
                ox = ooiedit(1,1);
                oy = ooiedit(2,1);
                oz = ooiedit(3,1);
                
                E = sqrt(((x-ox)^2 + (y-oy)^2 + (z-oz)^2));
                A = (x-ox)/E;
                B = (y-oy)/E;
                C = (z-oz)/E;
                D = A*x + B*y + C*z;
                
                for i = 1:length(V1new)
                    xV = V1new(1,i);
                    yV = V1new(2,i);
                    zV = V1new(3,i);
                    t = ((D) - A*xV - B*yV - C*zV) / (A*A + B*B + C*C);
                    xVnew = A*t + xV;
                    yVnew = B*t + yV;
                    zVnew = C*t + zV;
                    
                    distance = sqrt( ((xVnew - x)^2) + ((yVnew - y)^2) + ((zVnew - z)^2) );
                    
                    if distance <= GUI.Dmap.radius
                        %fprintf('%g, %g\n', i, distance);
                    else
                        V1new(1,i) = 0;
                        V1new(2,i) = 0;
                        V1new(3,i) = 0;
                        V1new(4,i) = 1;
                    end
                end
                
                for i = 1:length(V2new)
                    xV = V2new(1,i);
                    yV = V2new(2,i);
                    zV = V2new(3,i);
                    t = ((D) - A*xV - B*yV - C*zV) / (A*A + B*B + C*C);
                    xVnew = A*t + xV;
                    yVnew = B*t + yV;
                    zVnew = C*t + zV;
                    
                    distance = sqrt( ((xVnew - x)^2) + ((yVnew - y)^2) + ((zVnew - z)^2) );
                    
                    if distance <= GUI.Dmap.radius
                        %fprintf('%g, %g\n', i, distance);
                    else
                        V2new(1,i) = 1000;
                        V2new(2,i) = 1000;
                        V2new(3,i) = 1000;
                        V2new(4,i) = 1;
                    end
                end
                
                for i = 1:length(V1new)
                    counter = 0;
                    for ii = 1:length(V2new)
                        xV1 = V1new(1,i);
                        yV1 = V1new(2,i);
                        zV1 = V1new(3,i);
                        t = ((D) - A*xV1 - B*yV1 - C*zV1) / (A*A + B*B + C*C);
                        xV1new = A*t + xV1;
                        yV1new = B*t + yV1;
                        zV1new = C*t + zV1;
                        
                        xV2 = V2new(1,ii);
                        yV2 = V2new(2,ii);
                        zV2 = V2new(3,ii);
                        t = ((D) - A*xV2 - B*yV2 - C*zV2) / (A*A + B*B + C*C);
                        xV2new = A*t + xV2;
                        yV2new = B*t + yV2;
                        zV2new = C*t + zV2;
                        
                        distance = sqrt( ((xV1new - xV2new)^2) + ((yV1new - yV2new)^2) + ((zV1new - zV2new)^2) );
                        %HORIZONTAL
                        if distance <= GUI.Dmap.cutoff
                            counter = 1;                            
                        else
                        end
                        
                    end
                    if counter == 0
                        V1new(1,i) = 0;
                        V1new(2,i) = 0;
                        V1new(3,i) = 0;
                        V1new(4,i) = 1;
                    end
                        
                end                                                
                
                GUI.Dmap.nnid1{frame} = nearestneighbour(V1new,V2new,'Delaunay','off');
                GUI.Dmap.nnid2{frame} = nearestneighbour(V2new,V1new,'Delaunay','off');
            end
            
            % Build kdtree
            %[tmp, tmp, TreeRoot1] = kdtree( V1new', []);
            %[tmp, tmp, TreeRoot2] = kdtree( V2new', []);
            
            % Find nearest neighbour
            %[ GUI.Dmap.nnid1{frame}, GUI.Dmap.d1{frame}, TreeRoot2 ] = kdtreeidx([], V1new', TreeRoot2);
            %[ GUI.Dmap.nnid2{frame}, GUI.Dmap.d2{frame}, TreeRoot1 ] = kdtreeidx([], V2new', TreeRoot1);
            
            % Calculate distances
             GUI.Dmap.d1{frame} = zeros(length(V1new),1);
             for i = 1:length(V1new)
                 GUI.Dmap.d1{frame}(i) = norm(V1new(:,i)-V2new(:,GUI.Dmap.nnid1{frame}(i)));
             end
             
             GUI.Dmap.d2{frame} = zeros(length(V2new),1);
             for i = 1:length(V2new)
                 GUI.Dmap.d2{frame}(i) = norm(V2new(:,i)-V1new(:,GUI.Dmap.nnid2{frame}(i)));
             end
            
            % Find minimum distance and closest points
            [C I] = min(GUI.Dmap.d1{frame});
            GUI.Dmap.dmin{frame} = C;
            GUI.Dmap.closestpt{frame}(1) = I;
            GUI.Dmap.closestpt{frame}(2) = GUI.Dmap.nnid1{frame}(GUI.Dmap.closestpt{frame}(1));
            
            % Find average contact point
            
            %Create Blank matrix to collect vertex data
            DistMatrix = zeros(4, 0);
            
            n = 0; contact = zeros(2,3);
            for i = 1:length(hGUI.Region.v{GUI.selected_region1})
                if (GUI.Dmap.d1{frame}(i)) <=  GUI.Dmap.contact
                    contact(1,1:3) = contact(1,1:3) + hGUI.Region.v{GUI.selected_region1}(i, 1:3);
                    n = n+1;
                    addon = [ hGUI.Region.vid{GUI.selected_region1}(i); V1new(1, i); V1new(2, i); V1new(3, i)];
                    DistMatrix = cat(2, DistMatrix, addon);
                end
            end
            contact(1,1:3) = [0 0 0];
            
            n = 0;
            for i = 1:length(hGUI.Region.v{GUI.selected_region2})
                if (GUI.Dmap.d2{frame}(i)) <= GUI.Dmap.contact
                    contact(2,1:3) = contact(2,1:3) + hGUI.Region.v{GUI.selected_region2}(i, 1:3);
                    n = n+1;
                end
            end
            contact(2,1:3) = [0 0 0];
            GUI.Dmap.contactpt{frame} = contact;
            
            
            % Distance color map
            GUI.Dmap.color1{frame} = zeros(length(hGUI.Region.v{GUI.selected_region1}),3);
            for i = 1:length(hGUI.Region.v{GUI.selected_region1})
                %dratio = (GUI.Dmap.d1{frame}(i))/(GUI.Dmap.cutoff);
                if V1new(1, i) ~= 0
                    GUI.Dmap.color1{frame}(i,1:3) = [1 0 0];
                else
                    GUI.Dmap.color1{frame}(i,1:3) = [0/256 0/256 255/256];
                end
            end
            
            %Create Blank matrix to collect vertex data in face order
            FaceMatrix = zeros(4, 0);
            
            %Reorder Matrix to be in face order
            faceindex = DistMatrix(1,:);
            for i=1:1:length(F1)
                f1 = F1(i,1);
                f2 = F1(i,2);
                f3 = F1(i,3);
                [row, col] = find(faceindex == f1, 1);
                [row2, col2] = find(faceindex == f2, 1);
                [row3, col3] = find(faceindex == f3, 1);
                
                if ~isempty(row) && ~isempty(row2) && ~isempty(row3)
                    addon2 = [ F1(i,1); DistMatrix(2, col); DistMatrix(3, col); DistMatrix(4, col)];
                    FaceMatrix = cat(2, FaceMatrix, addon2);
                    addon3 = [ F1(i,2); DistMatrix(2, col2); DistMatrix(3, col2); DistMatrix(4, col2)];
                    FaceMatrix = cat(2, FaceMatrix, addon3);
                    addon4 = [ F1(i,3); DistMatrix(2, col3); DistMatrix(3, col3); DistMatrix(4, col3)];
                    FaceMatrix = cat(2, FaceMatrix, addon4);
                end
            end
            
            
            
            %Display the full vertex matrix
            %fprintf('These are your interacting vertex indices and coordinates for frame %g:', frame);
            %disp(FaceMatrix);
            %fprintf('\n');
            
            %Use these Coordinates to calculate Surface Area of Interacting
            %Regions:
            [rows, cols] = size(FaceMatrix); %#ok<ASGLU>
            TotalArea = 0;
            for i = 1:3:(cols-2)
                P1 = [FaceMatrix(2, i) FaceMatrix(3, i) FaceMatrix(4, i)];
                P2 = [FaceMatrix(2, (i+1)) FaceMatrix(3, (i+1)) FaceMatrix(4, (i+1))];
                P3 = [FaceMatrix(2, (i+2)) FaceMatrix(3, (i+2)) FaceMatrix(4, (i+2))];
                A = (1/2)*norm(cross(P2-P1,P3-P1));
                TotalArea = TotalArea + abs(A);
            end
            %fprintf('This is your interacting surface area for frame %g', frame);
            %disp(TotalArea);
            %fprintf('\n');
            
            addon5 = [frame TotalArea];
            GUI.TotalAreaMatrix = cat(1, GUI.TotalAreaMatrix, addon5);
            
            
            GUI.Dmap.color2{frame} = zeros(length(hGUI.Region.v{GUI.selected_region2}),3);
            for i = 1:length(hGUI.Region.v{GUI.selected_region2})
                if V2new(1,i) ~= 1000
                    GUI.Dmap.color2{frame}(i,1:3) = [1 1 0];
                else
                    GUI.Dmap.color2{frame}(i,1:3) = [255/256 165/256 0/256];
                end
            end
            
            % Update progress bar
            progressbar(frame/hGUI.num_kin);
            
        end
        fprintf('This is your total IA by frame: \n');
        disp(GUI.TotalAreaMatrix);
        fprintf('%g\n', GUI.TotalAreaMatrix(:,2));
        
%         
%         %figure(GUI.hAxes)
%         hold on;
%         plot3(GUI.Region{1}(I,1),GUI.Region{1}(I,2),GUI.Region{1}(I,3),'g.')
%         plot3(GUI.Region{2}(id(I),1),GUI.Region{2}(id(I),2),GUI.Region{2}(id(I),3),'r.')
%         line([GUI.Region{1}(I,1); GUI.Region{2}(id(I),1)],[GUI.Region{1}(I,2); GUI.Region{2}(id(I),2)],[GUI.Region{1}(I,3); GUI.Region{2}(id(I),3)])
%         
    end

end