//#include "../src/main.cpp"
//#define CATCH_CONFIG_MAIN
//#include "catch.hpp"
//#include "../src/KyleAVLTree.cpp"
//
///*
//	To check output (At the Project1 directory):
//		g++ -std=c++14 -Werror -Wuninitialized -o build/test test-unit/test.cpp && build/test
//*/
//
//TEST_CASE("Incorrect Insert", "[flag]"){
//	
//	KyleAVLTree tree;   // Create a Tree object 
//
//	std::vector<string> badInputs = {
//		"insert \"A11y\" 12345678",
//		"remove \"Name\"",
//		"printPostorder 123",
//		"insert 12345678",
//		"removeInorder wasd"
//	};
//
//	std::vector<string> expectedOut = {"unsuccessful\n", "unsuccessful\n", "unsuccessful\n", "unsuccessful\n", "unsuccessful\n"};
//
//	std::vector<string> actualOut;
//
//	for (unsigned int i = 0; i < 5; i++)
//	{
//		istringstream newCin(badInputs[i]); // Creates a mock input of commands
//		auto stdoutBuffer = std::cout.rdbuf();
//		std::ostringstream oss;
//		std::cout.rdbuf(oss.rdbuf());
//		parseAndPerform(newCin, tree);
//		std::cout.rdbuf(stdoutBuffer);
//		actualOut.push_back(oss.str());
//	}
//
//	REQUIRE(actualOut == expectedOut);
//}
//
//TEST_CASE("Three Edge Cases", "[flag]"){
//	
//	KyleAVLTree tree;   // Create a Tree object 
//	tree.insert("test1", "00000001");
//	tree.insert("test2", "00000002");
//	tree.insert("test3", "00000003");
//	tree.insert("test4", "00000004");
//	tree.insert("test5", "00000005");
//	tree.insert("test6", "00000006");
//	tree.insert("test7", "00000007");
//	tree.insert("test8", "00000008");
//
//	std::vector<string> badInputs = {
//		"search 00000009",
//		"remove 00000009",
//		"removeInorder 9",
//		"printInorder"
//	};
//
//	std::vector<string> expectedOut = {"unsuccessful\n", "unsuccessful\n", "unsuccessful\n", "test1, test2, test3, test4, test5, test6, test7, test8\n"};
//
//	std::vector<string> actualOut;
//
//	for (unsigned int i = 0; i < 4; i++)
//	{
//		istringstream newCin(badInputs[i]); // Creates a mock input of commands
//		auto stdoutBuffer = std::cout.rdbuf();
//		std::ostringstream oss;
//		std::cout.rdbuf(oss.rdbuf());
//		parseAndPerform(newCin, tree);
//		std::cout.rdbuf(stdoutBuffer);
//		actualOut.push_back(oss.str());
//	}
//
//	REQUIRE(actualOut == expectedOut);
//}
//
//TEST_CASE("Rotations", "[flag]"){
//	
//	KyleAVLTree tree;   // Create a Tree object 
//	// left rotation
//	tree.insert("test10", "00000010");
//	tree.insert("test11", "00000011");
//	tree.insert("test12", "00000012");
//
//	// right left rotation
//	tree.insert("test14", "00000014");
//	tree.insert("test13", "00000013");
//
//	// right rotation
//	tree.insert("test9", "00000009");
//	tree.insert("test8", "00000008");
//
//	// left right rotation
//	tree.insert("test6", "00000006");
//	tree.insert("test7", "00000007");
//
//
//	string expectedOut = {"test6, test7, test8, test9, test10, test11, test12, test13, test14\n"};
//
//	string actualOut;
//
//	istringstream newCin("printInorder"); // Creates a mock input of commands
//	auto stdoutBuffer = std::cout.rdbuf();
//	std::ostringstream oss;
//	std::cout.rdbuf(oss.rdbuf());
//	parseAndPerform(newCin, tree);
//	std::cout.rdbuf(stdoutBuffer);
//	actualOut = oss.str();
//	REQUIRE(actualOut == expectedOut);
//}
//
//TEST_CASE("Deletions", "[flag]"){
//	
//	KyleAVLTree tree;   // Create a Tree object 
//	// left rotation
//	tree.insert("test10", "00000010");
//	tree.insert("test11", "00000011");
//	tree.insert("test12", "00000012");
//
//	// right left rotation
//	tree.insert("test14", "00000014");
//	tree.insert("test13", "00000013");
//
//	// right rotation
//	tree.insert("test9", "00000009");
//	tree.insert("test8", "00000008");
//
//	// left right rotation
//	tree.insert("test6", "00000006");
//	tree.insert("test7", "00000007");
//
//	tree.remove("00000007"); // two children
//	tree.remove("00000014"); // no children
//	tree.remove("00000006"); // one child
//
//
//	string expectedOut = {"test8, test9, test10, test11, test12, test13\n"};
//
//	string actualOut;
//
//	istringstream newCin("printInorder"); // Creates a mock input of commands
//	auto stdoutBuffer = std::cout.rdbuf();
//	std::ostringstream oss;
//	std::cout.rdbuf(oss.rdbuf());
//	parseAndPerform(newCin, tree);
//	std::cout.rdbuf(stdoutBuffer);
//	actualOut = oss.str();
//	REQUIRE(actualOut == expectedOut);
//}
//
//TEST_CASE("Insert Large", "[flag]"){
//	KyleAVLTree inputTree;
//    string expectedOut, actualOut, actualOut2;
//
//    for(int i = 0; i < 100; i++)
//    {
//            inputTree.insert(to_string(i), to_string(i));
//    }
//	
//	for (int i = 0; i < 10; i++)
//	{
//		inputTree.remove(to_string(i*7));
//	}
//	
//	auto stdoutBuffer = std::cout.rdbuf();
//	std::ostringstream oss;
//	std::cout.rdbuf(oss.rdbuf());
//    inputTree.removeInOrder(89);
//	std::cout.rdbuf(stdoutBuffer);
//	actualOut = oss.str();
//	expectedOut = "successful\n";
//	REQUIRE(actualOut == expectedOut);
//	
//	// Not randomized like I would like, but demonstrates the concept of being able to remove the last (90th) element.
//	auto stdoutBuffer2 = std::cout.rdbuf();
//	std::ostringstream oss2;
//	std::cout.rdbuf(oss2.rdbuf());
//    inputTree.removeInOrder(89);
//	std::cout.rdbuf(stdoutBuffer2);
//	actualOut2 = oss2.str();
//	expectedOut = "unsuccessful\n";
//	REQUIRE(actualOut2 == expectedOut);
//}