- Focus on rotations for each of the nodes, balance factors, rotations. 
- Rotate towards the short side always. The only balance factors that need to be recalculated are those nodes involved
    in rotations.
- Three main parts to the project 1) AVL Construction with node
                                  2) Parsing input
                                  3) Main function
- Replace with inorder successor (get ID and name of one node and send to the other)
- Remember to use getline with delimiter 41:00 minutes into youtube variable
- insert(), traverse(), search(), and remove()

Things to add - separate traversal helper functions. Copy assignment and copy constructor