#include <iostream>
#include "KyleAVLTree.h"

// Constructor, Destructor, Destructor Helper
KyleAVLTree::KyleAVLTree()
{
    _root = nullptr;
}
KyleAVLTree::~KyleAVLTree()
{
    if (_root != nullptr)
        deletePostOrder(_root);
}
void KyleAVLTree::deletePostOrder(GatorNode*& localRoot)
{
    if (localRoot->_left != nullptr)
        deletePostOrder(localRoot->_left);
    if (localRoot->_right != nullptr)
        deletePostOrder(localRoot->_right);
    delete localRoot;
}

// Insert and Insert Helper
void KyleAVLTree::insert(const string name, const string iD)
{
    _root = insert(_root, name, iD); // recursively insert and balance tree, return root
}
GatorNode*& KyleAVLTree::insert(GatorNode*& localRoot, const string& name, const string& iD)
{
    if (localRoot == nullptr)
    {
        localRoot = new GatorNode(name,iD);
        std::cout << "successful" << std::endl; // successfully found base case of recursion
        return localRoot; // once you get to leaf return, balance is 0 at leaf 
    }

    if (iD < localRoot->_iD)
    {
        localRoot->_left = insert(localRoot->_left, name, iD);
        localRoot->balance();
        localRoot = checkForRotations(localRoot); // in the case of rotation, local root can be changed
    }
    else if (iD > localRoot->_iD)
    {
        localRoot->_right = insert(localRoot->_right, name, iD);
        localRoot->balance();
        localRoot = checkForRotations(localRoot);
    }
    else
        std::cout << "unsuccessful" << std::endl; // unsuccessful denotes that you have found a duplicate ID
    
    return localRoot;
}

// Check for Rotations and Rotate
GatorNode*& KyleAVLTree::checkForRotations(GatorNode*& localRoot)
{
    if (localRoot->_balance > -2 && localRoot->_balance < 2)
        return localRoot;
    else if (localRoot->_balance > 1) // left side is heavy
    {
        if (localRoot->_left->_balance > 0) // left left
            localRoot = right(localRoot);
        else                                // left right
            localRoot = leftRight(localRoot);
    }
    else // right side is heavy
    {
        if (localRoot->_right->_balance < 0) // right right
            localRoot = left(localRoot);
        else                                 // right left
            localRoot = rightLeft(localRoot);
    }
    return localRoot;
}
GatorNode*& KyleAVLTree::left(GatorNode*& localRoot)
{
    GatorNode* child = localRoot->_right;
    localRoot->_right = child->_left;
    child->_left = localRoot;
    localRoot->balance();
    child->balance();
    localRoot = child;
    return localRoot;
}
GatorNode*& KyleAVLTree::right(GatorNode*& localRoot)
{
    GatorNode* child = localRoot->_left;
    localRoot->_left = child->_right;
    child->_right = localRoot;
    localRoot->balance();
    child->balance();
    localRoot = child;
    return localRoot;
}
GatorNode*& KyleAVLTree::rightLeft(GatorNode*& localRoot)
{
    GatorNode* child = localRoot->_right;
    localRoot->_right = right(child);
    localRoot = left(localRoot);
    return localRoot;
}
GatorNode*& KyleAVLTree::leftRight(GatorNode*& localRoot)
{
    GatorNode* child = localRoot->_left;
    localRoot->_left = left(child);
    localRoot = right(localRoot);
    return localRoot;
}

// Search and Search Helper
void KyleAVLTree::search(const string findMe)
{
    bool found = false;
    if (_root != nullptr)
        search(_root, findMe, found);
    if (found == false)
        std::cout << "unsuccessful" << std::endl;
}
GatorNode* KyleAVLTree::search(GatorNode*& localRoot, const string& findMe, bool& found)
{
    // If string is iD:
    if (isdigit(findMe[0]))
    {
        if (localRoot->_iD == findMe)
        {
            std::cout << localRoot->_name << std::endl;
            found = true;
            return localRoot;
        }
        if (localRoot->_left != nullptr && findMe < localRoot->_iD)
            search(localRoot->_left, findMe, found);
        if (localRoot->_right != nullptr && findMe > localRoot->_iD)
            search(localRoot->_right, findMe, found);
    }
    // If string is name (use preorder traversal)
    if (isalpha(findMe[0]))
    {
        if (localRoot->_name == findMe)
        {
            std::cout << localRoot->_iD << std::endl;
            found = true;
        }
        if (localRoot->_left != nullptr)
            search(localRoot->_left, findMe, found);
        if (localRoot->_right != nullptr)
            search(localRoot->_right, findMe, found);
    }
    return nullptr;
}

// Remove and Helper 
void KyleAVLTree::remove(const string iD)
{
        if (_root != nullptr)
            remove(_root,iD);
}
void KyleAVLTree::remove(GatorNode*& localRoot, const string& iD)
{
    if (localRoot == nullptr)
    {
        std::cout << "unsuccessful" << std::endl;
        return;
    }
    if (localRoot->_iD == iD) // Success!
        {
            std::cout << "successful" << std::endl;
            GatorNode* inOrderSuccessor = inOrderSuc(localRoot);
            if (inOrderSuccessor == nullptr)
            {
                delete localRoot;
                localRoot = nullptr;
            }
            else
            {
            localRoot->_iD = inOrderSuccessor->_iD;
            localRoot->_name = inOrderSuccessor->_name;
            }
        }
    else if (iD < localRoot->_iD)
        remove(localRoot->_left, iD);
    else 
        remove(localRoot->_right, iD);
}

GatorNode* KyleAVLTree::inOrderSuc(GatorNode*& localRoot)
{
    if (localRoot->_right == nullptr && localRoot->_left == nullptr)
        return nullptr;
    else if (localRoot->_right == nullptr) // one child
    {
        localRoot->_iD = localRoot->_left->_iD;
        localRoot->_name = localRoot->_left->_name;
        localRoot->_right = localRoot->_left->_right;
        auto copy = localRoot->_left->_left;
        delete localRoot->_left;
        localRoot->_left = copy;
    }
    else if (localRoot->_left == nullptr) // one child
    {
        localRoot->_iD = localRoot->_right->_iD;
        localRoot->_name = localRoot->_right->_name;
        localRoot->_left = localRoot->_right->_left;
        auto copy = localRoot->_right->_right;
        delete localRoot->_right;
        localRoot->_right = copy;
    }
    else // two children
    {
        // Find in order
        auto inOrder = localRoot->_right;
        auto inOrderChild = inOrder->_left;
        GatorNode* inOrderGChild = nullptr;
        if (inOrderChild != nullptr)
            inOrderGChild = inOrderChild->_left;
        while (inOrderGChild != nullptr)
        {
            inOrder = inOrder->_left;
            inOrderChild = inOrderChild->_left;
            inOrderGChild = inOrderGChild->_left;
        }
        if (inOrderChild == nullptr)
        {
            localRoot->_iD = inOrder->_iD;
            localRoot->_name = inOrder->_name;
            auto copy = inOrder->_right;
            delete inOrder;
            localRoot->_right = copy;
        }
        else
        {
            // inOrderChild is the one we want to copy
            localRoot->_iD = inOrderChild->_iD;
            localRoot->_name = inOrderChild->_name;
            inOrder->_left = inOrderChild->_right;
            inOrder->balance();
            delete inOrderChild;
        }
    }
    localRoot->balance();
    return localRoot;
}

void KyleAVLTree::removeInOrder(unsigned int n)
{
    if (_root != nullptr)
    {
        string iDToRemove = "";
        if (n==0)
        {
            GatorNode* localRoot = _root;
            while (localRoot->_left != nullptr)
                localRoot = localRoot->_left;
            iDToRemove = localRoot->_iD;
        }
        else
            inOrder(_root, n, iDToRemove);
        if (n==0)
        {
            remove(_root, iDToRemove);
        }
        else
            std::cout << "unsuccessful" << std::endl;
    }
}

void KyleAVLTree::inOrder(GatorNode*& localRoot, unsigned int& n, string& toReturn)
{
        if (n==0)
        {
            toReturn = localRoot->_iD;
            return;
        }
        if (localRoot->_left != nullptr)
            inOrder(localRoot->_left,n,toReturn);
        n-=1;
        if (localRoot->_right != nullptr)
        {
            inOrder(localRoot->_right,n,toReturn);
        }
}

// Print Operations
void KyleAVLTree::printPreOrder()
{
    bool flag = false;
    printPreOrder(_root, flag);
    std::cout << std::endl;
}
void KyleAVLTree::printPreOrder(GatorNode*& localRoot, bool& flag) const
{
    if (flag == false)
    {
        std::cout << localRoot->_name;
        flag = true;
    }
    else 
        std::cout  << ", " << localRoot->_name;
    if (localRoot->_left != nullptr)
        printPreOrder(localRoot->_left, flag);
    if (localRoot->_right != nullptr)
        printPreOrder(localRoot->_right, flag);
}

void KyleAVLTree::printInOrder()
{
    bool flag = false;
    printInOrder(_root, flag);
    std::cout << std::endl;
}
void KyleAVLTree::printInOrder(GatorNode*& localRoot, bool& flag) const
{
    if (localRoot->_left != nullptr)
        printInOrder(localRoot->_left, flag);
    if (flag == false)
    {
        std::cout << localRoot->_name;
        flag = true;
    }
    else 
        std::cout  << ", " << localRoot->_name;
    if (localRoot->_right != nullptr)
        printInOrder(localRoot->_right, flag);
}

void KyleAVLTree::printPostOrder()
{
    bool flag = false;
    printPostOrder(_root, flag);
    std::cout << std::endl;
}
void KyleAVLTree::printPostOrder(GatorNode*& localRoot, bool& flag) const
{
    if (localRoot->_left != nullptr)
        printPostOrder(localRoot->_left, flag);
    if (localRoot->_right != nullptr)
        printPostOrder(localRoot->_right, flag);
    if (flag == false)
    {
        std::cout << localRoot->_name;
        flag = true;
    }
    else 
        std::cout  << ", " << localRoot->_name;
}

void KyleAVLTree::printLevelCount() const
{
    if (_root != nullptr)
        std::cout << _root->_height << std::endl;
    else
        std::cout << 0 << std::endl;
}