#include <iostream>
#include <sstream>
#include "KyleAVLTree.h"
using namespace std;

/* Note: 
	1. You will have to comment main() when unit testing your code because catch uses its own main().
	2. You will submit this main.cpp file and any header files you have on Gradescope. 
*/

// Parsing Function to call tree reference functions and validate input
void parseAndPerform(istringstream& newCin, KyleAVLTree& tree);

int main()
{
	KyleAVLTree tree;
	unsigned int numberOfCommands = 0;
	cin >> numberOfCommands;
	string line;
	getline(cin, line);

	for (unsigned int i = 0; i < numberOfCommands; i++)
	{  
		getline(cin, line);
		istringstream newCin(line);
		parseAndPerform(newCin, tree);
	}

	return 0;
}

void parseAndPerform(istringstream& newCin, KyleAVLTree& tree) // a lot of ifs...
{
	string token;
	string name;
	string iD;
	if (newCin.peek() == 'p') // one of the print functions
		getline(newCin, token);
	else 
		getline(newCin, token, ' ');

	if (token == "insert")
	{
		getline(newCin, token, '\"'); // get rid of first quote
		if (token == "")
		{
			getline(newCin, name, '\"');
			getline(newCin, token, ' ');
			getline(newCin, iD);
			for (unsigned int i = 0; i < name.length(); i++)
				{if (!isalpha(name[i]) and name[i] != ' ')
					iD = "0";}
			if (iD.length() == 8 && isdigit(iD[0]) && isdigit(iD[1]) && isdigit(iD[2]) && isdigit(iD[3]) && isdigit(iD[4]) && isdigit(iD[5]) && isdigit(iD[6]) && isdigit(iD[7]) )
				{tree.insert(name, iD); return;}
		}
	}
	else if (token == "remove")
	{
		getline(newCin, iD);
		if (iD.length() == 8 && isdigit(iD[0]) && isdigit(iD[1]) && isdigit(iD[2]) && isdigit(iD[3]) && isdigit(iD[4]) && isdigit(iD[5]) && isdigit(iD[6]) && isdigit(iD[7]) )
			{tree.remove(iD); return;}
	}
	else if (token == "search")
	{
		// Two cases for search -> isDigit or isAlpha
		if (isdigit(newCin.peek())) // iD search
		{
			getline(newCin, iD);
			if (iD.length() == 8 && isdigit(iD[0]) && isdigit(iD[1]) && isdigit(iD[2]) && isdigit(iD[3]) && isdigit(iD[4]) && isdigit(iD[5]) && isdigit(iD[6]) && isdigit(iD[7]) )
				{tree.search(iD); return;}
		}
		else
		{
			getline(newCin, token, '\"'); // get rid of first quote
			if (token == "")
			{
				getline(newCin, name, '\"');
				for (unsigned int i = 0; i < name.length(); i++)
				{
					if (!isalpha(name[i]) and name[i] != ' ')
						{cout << "unsuccessful" << endl;
						return;}
				}
				tree.search(name); return;
			}
		}
	}
	else if (token == "printInorder")
	{
		tree.printInOrder(); return;
	}
	else if (token == "printPreorder")
	{
		tree.printPreOrder(); return;
	}
	else if (token == "printPostorder")
	{
		tree.printPostOrder(); return;
	}
	else if (token == "printLevelCount")
	{
		tree.printLevelCount(); return;
	}
	else if (token == "removeInorder")
	{
		getline(newCin, iD); // iD is index N here
		try
			{tree.removeInOrder(stoi(iD));}
		catch(...) {cout <<"unsuccessful" << endl;}
		return;
	}
	
	cout << "unsuccessful" << endl;
	return;
}