#pragma once
#include <string>
#include <iostream>
using std::string;

struct GatorNode
{
    string _name;
    string _iD;
    GatorNode* _left;
    GatorNode* _right;
    int _height;
    int _balance;

    // Constructor
    GatorNode(const string name, const string iD) : _name(name), _iD(iD), _left(nullptr), _right(nullptr), _height(1), _balance(0) {}

    // Balance
    void balance() 
    {
        int leftHeight = 0;
        int rightHeight = 0;
        if (_left != nullptr)
            leftHeight = _left->_height;
        if (_right != nullptr)
            rightHeight = _right->_height; 
        _height = 1 + std::max(leftHeight,rightHeight);
        this->_balance = leftHeight - rightHeight;
    }

    // Comparison operator overloads
    //bool operator<(GatorNode*& rhs) {return this->_iD < rhs->_iD;} // less than
    //bool operator==(GatorNode*& rhs) {return this->_iD == rhs->_iD;} // equivalence
};

class KyleAVLTree
{
    private:
        GatorNode* _root;

        // Private Helper Functions (useful for recursion)
        GatorNode*& insert(GatorNode*& localRoot, const string& name, const string& iD);
        void remove(GatorNode*& localRoot, const string& iD); // replace with inorder successor
        GatorNode* inOrderSuc(GatorNode*& localRoot);
        GatorNode* search(GatorNode*& localRoot, const string& findMe, bool& found); // used by search(string)
        void deletePostOrder(GatorNode*& localRoot);
        void inOrder(GatorNode*& localRoot, unsigned int& n, string& toReturn);

        // Operations
        void printInOrder(GatorNode*& localRoot, bool& flag) const;
        void printPreOrder(GatorNode*& localRoot, bool& flag) const;
        void printPostOrder(GatorNode*& localRoot, bool& flag) const;

        // Rotations (after insertion / removal)
        GatorNode*& checkForRotations(GatorNode*& localRoot);
        GatorNode*& left(GatorNode*& localRoot);
        GatorNode*& right(GatorNode*& localRoot);
        GatorNode*& rightLeft(GatorNode*& localRoot);
        GatorNode*& leftRight(GatorNode*& localRoot);

    public:
        // Constructor
        KyleAVLTree();
        
        // Big Three
        //KyleAVLTree& operator=(const KyleAVLTree& rhs); // Copy Assignment
        //KyleAVLTree(const KyleAVLTree& rhs); // Copy Constructor 
        ~KyleAVLTree(); // delete all nodes // Destructor

        // Setters (Mutators)
        void insert(const string name, const string iD); // accompanied by helper function
        void remove(const string iD); // accompanied by helper function
        void removeInOrder(unsigned int n); // uses inorder traversal

        // Getters (Accessors)
        void search(const string findMe);
        //void search(const string name) const; // needs to use preorder traversal in case of multiple

        // Operations
        void printInOrder();
        void printPreOrder();
        void printPostOrder();
        void printLevelCount() const;
};