Gui_MainWindow and NearestNeighbour_tool are from a huge library 
of functions that the lab I did research at worked on together. I did 
a lot of work on these files but am not claiming them in their entirety. 
Total props to the whole team - this project was huge! 
