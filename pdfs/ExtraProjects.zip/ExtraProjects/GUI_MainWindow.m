% -------------------------------------------------------------------------
%
% Filename:     
% Coded by:
% Adapted by:
% Date:
%
% -------------------------------------------------------------------------
%
% Description:
%
% 
%
% Input:
%
%   
%
% Output:
%
%
%
% Usage:  
%
%
%
% -------------------------------------------------------------------------
function varargout = GUI_MainWindow()

    % GUI variable structure
    GUI.name = 'Surface Separation Software';    % Application name
    GUI.hPatch = cell(0);
    GUI.hTform = cell(0);
    GUI.Region = struct('v',{[]},'vid',{[]},'modelid',{[]});
    GUI.hRegion = cell(0);
    GUI.Dmap = cell(0);
    GUI.hClosestpt = cell(0);
    GUI.hContactpt = cell(0);
    GUI.frame = 0;
    GUI.num_kin = 0;
    GUI.pathname = '';
    GUI.ptsmethod = 1;
    GUI.FunColor = 0;
    % Layout GUI
    GUI_Layout();
    
%--------------------------------------------------------------------------
% GUI Objects and Layout
%--------------------------------------------------------------------------

    function GUI_Layout()
        % Get local screen size
        GUI.scrnsz = get(0,'ScreenSize');
        
        % Create main figure
        GUI.hFigure = figure('MenuBar','none',...
                             'Toolbar','none',...
                             'Name',GUI.name,...
                             'Color','w',...
                             'NumberTitle','off',...
                             'Resize','on',...
                             'ResizeFcn',@hFigure_resize,...
                             'Position',[GUI.scrnsz(3)/2-GUI.scrnsz(4)/4 GUI.scrnsz(4)/2-GUI.scrnsz(4)/4 GUI.scrnsz(4)/2 GUI.scrnsz(4)/2],...
                             'Renderer','OpenGL');
                         
            % Create rendering axes             
            GUI.hAxes = axes('Parent',GUI.hFigure,...
                             'ButtonDownFcn',@axes_buttondown,...
                             'Color','none',...
                             'Units','normalized',...
                             'Position',[0 0 1 1]);
                             axis off;      % Turn axes lines off
                             light;         % Add scene light

        GUI.hSlider = uicontrol('Parent',GUI.hFigure,...
                                'Style','slider',...
                                'Enable','off',...
                                'Value',1,...
                                'Min',1,...
                                'Max',10,...
                                'SliderStep',[.1 .2],...
                                'Callback',@UI_Slider,...
                                'Position',[0 12 GUI.scrnsz(4)/2 20]);
                            
            % Create panel
            GUI.hPanel = uipanel('Parent',GUI.hFigure,...
                                 'BackgroundColor',[232/256 232/256 232/256],...
                                 'BorderType','etchedin',...
                                 'Units','pixels',...
                                 'Position',[0 0 GUI.scrnsz(4)/2 18]);
                             
            % Create statusbar
            GUI.hStatusbar = uicontrol('Parent',GUI.hPanel,...
                                       'Style','text',...
                                       'HorizontalAlignment','left',...
                                       'BackgroundColor',[232/256 232/256 232/256],...
                                       'String','Ready...',...
                                       'Units','pixels',...
                                       'Position',[0 0 GUI.scrnsz(4)/2-5 12]);

        % Create MenuBar                            
        MenuBar(GUI.hFigure);
        
        % Create ToolBar
        ToolBar(GUI.hFigure);
        
        axis equal
        % Add Standard Cameratoolbar
        cameratoolbar
        cameratoolbar('SetCoordSys','none')        % Change default rotation axis
        view3d rot
        
        
        
        % Additional settings
        material dull                           % Dull material lighting effects
        daspect([1 1 1])                        % Uniform plotting axes
       
        % Set GUI document data
        guidata(GUI.hFigure,GUI)
        
    end %GUI_Layout

%--------------------------------------------------------------------------
% MenuBar Objects
%--------------------------------------------------------------------------
    
    function MenuBar(hFigure)
        % File Menu
        GUI.hMenu_file = uimenu('Parent',hFigure,...
                                'Label','File',...
                                'Separator','off',...
                                'Enable','on');
            % File->Open... Menu                 
            GUI.hMenu_file_open = uimenu('Parent',GUI.hMenu_file,...
                                         'Label','Open...',...
                                         'Separator','off',...
                                         'Enable','on');
                                     
                % File->Open->ASCII STL Model Menu                 
                GUI.hMenu_file_open_stlamodel = uimenu('Parent',GUI.hMenu_file_open,...
                                             'Label','ASCII STL Model (.stl)...',...
                                             'Separator','off',...
                                             'Enable','on',...
                                             'Callback',@LoadSTLModelascii_callback);
                                     
                % File->Open->ASCII STL Model Menu                 
                GUI.hMenu_file_open_stlbmodel = uimenu('Parent',GUI.hMenu_file_open,...
                                             'Label','Binary STL Model (.stl)...',...
                                             'Separator','off',...
                                             'Enable','on',...
                                             'Callback',@LoadSTLModelbinary_callback);
                                         
                % File->Open->MATLAB Model Menu                 
                GUI.hMenu_file_open_matlabmodel = uimenu('Parent',GUI.hMenu_file_open,...
                                             'Label','MATLAB Model (.model)...',...
                                             'Separator','on',...
                                             'Enable','on',...
                                             'Callback',@LoadMATLABModel_callback); 

                                     
                % File->Open->MATLAB Region Menu                 
                GUI.hMenu_file_open_matlabregion = uimenu('Parent',GUI.hMenu_file_open,...
                                             'Label','MATLAB Region (.region)...',...
                                             'Separator','off',...
                                             'Enable','off',...
                                             'Callback',@LoadMATLABRegion_callback); 
                                         
            % File->Save... Menu                 
            GUI.hMenu_file_save = uimenu('Parent',GUI.hMenu_file,...
                                         'Label','Save...',...
                                         'Separator','on',...
                                         'Enable','on');
                                     
                % File->Save->Model As... Menu                 
                GUI.hMenu_file_savemodel = uimenu('Parent',GUI.hMenu_file_save,...
                                             'Label','Model As...',...
                                             'Separator','off',...
                                             'Enable','off',...
                                             'Callback',@SaveModelAs_callback); 

                % File->Save->Region As... Menu                 
                GUI.hMenu_file_saveregion = uimenu('Parent',GUI.hMenu_file_save,...
                                             'Label','Region As...',...
                                             'Separator','off',...
                                             'Enable','off',...
                                             'Callback',@SaveRegionAs_callback); 

                % File->Save->Closest Points As... Menu                 
                GUI.hMenu_file_saveclosest = uimenu('Parent',GUI.hMenu_file_save,...
                                             'Label','Closest Points As...',...
                                             'Separator','on',...
                                             'Enable','off',...
                                             'Callback',@SaveClosestAs_callback);

                % File->Save->Contact Points As... Menu                 
                GUI.hMenu_file_savecontact = uimenu('Parent',GUI.hMenu_file_save,...
                                             'Label','Contact Points As...',...
                                             'Separator','off',...
                                             'Enable','off',...
                                             'Callback',@SaveContactAs_callback);
                                         
                % File->Save->Movie As... Menu                 
                GUI.hMenu_file_savemovie = uimenu('Parent',GUI.hMenu_file_save,...
                                             'Label','Movie As...',...
                                             'Separator','on',...
                                             'Enable','off',...
                                             'Callback',@SaveMovieAs_callback); 
            % File->Set Path... Menu                 
            GUI.hMenu_file_save = uimenu('Parent',GUI.hMenu_file,...
                                         'Label','Set Path...',...
                                         'Separator','on',...
                                         'Enable','on',...
                                         'Callback',@FileSetPath_callback);
            
            % File->Preferences... Menu                 
            GUI.hMenu_file_save = uimenu('Parent',GUI.hMenu_file,...
                                         'Label','Preferences...',...
                                         'Separator','off',...
                                         'Enable','on',...
                                         'Callback',@FilePreferences_callback);                                     
        % Tools Menu
        GUI.hMenu_tools = uimenu('Parent',hFigure,...
                                 'Label','Tools',...
                                 'Separator','off',...
                                 'Enable','on');
                             
            % Tools->Transform... Menu                 
            GUI.hMenu_tools_transform = uimenu('Parent',GUI.hMenu_tools,...
                                         'Label','Transform Model...',...
                                         'Separator','off',...
                                         'Enable','off',...
                                         'Callback',@Transform_callback);
                                     
            % Tools->Create Region... Menu                 
            GUI.hMenu_tools_createregion = uimenu('Parent',GUI.hMenu_tools,...
                                         'Label','Create region object from model...',...
                                         'Separator','on',...
                                         'Enable','off',...
                                         'Callback',@CreateRegion_callback);
                                     
            % Tools->Nearest Neighbor... Menu                 
            GUI.hMenu_tools_nearestneighbour = uimenu('Parent',GUI.hMenu_tools,...
                                         'Label','Nearest neighbor...',...
                                         'Separator','on',...
                                         'Enable','off',...
                                         'Callback',@NearestNeighbour_callback);
                   
            % Tools->Joint... Menu                 
            GUI.hMenu_tools_joint = uimenu('Parent',GUI.hMenu_tools,...
                                         'Label','Joint',...
                                         'Separator','on',...
                                         'Enable','off');
                   
                % Tools->Joint->Knee Menu                 
                GUI.hMenu_tools_joint_knee = uimenu('Parent',GUI.hMenu_tools_joint,...
                                             'Label','Knee',...
                                             'Separator','off',...
                                             'Enable','off');
                                     
                    % Tools->Joint->Knee->Center of rotation plot Menu                 
                    GUI.hMenu_tools_joint_knee_cor = uimenu('Parent',GUI.hMenu_tools_joint_knee,...
                                                 'Label','Center of Rotation Plot',...
                                                 'Separator','off',...
                                                 'Enable','off',...
                                                 'Callback',@KneeCORplot_callback);
                                         
                    % Tools->Joint->Knee->Save Anatomic Kinematics As... Menu                 
                    GUI.hMenu_tools_joint_knee_kin = uimenu('Parent',GUI.hMenu_tools_joint_knee,...
                                                 'Label','Save Anatomic Kinematics As',...
                                                 'Separator','off',...
                                                 'Enable','off',...
                                                 'Callback',@KneeSaveKin_callback);
                                             
        % View Menu
        GUI.hMenu_view = uimenu('Parent',hFigure,...
                                 'Label','View',...
                                 'Separator','off',...
                                 'Enable','on');
                             
            % View->Hide/Show... Menu                 
            GUI.hMenu_view_hideshow = uimenu('Parent',GUI.hMenu_view,...
                                         'Label','Hide/Show Object...',...
                                         'Separator','off',...
                                         'Enable','on');
                     
                % View->Show/Hide->Models... Menu                 
                GUI.hMenu_view_hideshow_models = uimenu('Parent',GUI.hMenu_view_hideshow,...
                                             'Label','Models...',...
                                             'Separator','off',...
                                             'Enable','off',...
                                             'Callback',@HideShowModels_callback);
                                     
                % View->Show/Hide->Regions... Menu                 
                GUI.hMenu_view_hideshow_regions = uimenu('Parent',GUI.hMenu_view_hideshow,...
                                             'Label','Regions...',...
                                             'Separator','off',...
                                             'Enable','off',...
                                             'Callback',@HideShowRegions_callback);
                                         
                % View->Show/Hide->Closest Points... Menu                 
                GUI.hMenu_view_hideshow_closest = uimenu('Parent',GUI.hMenu_view_hideshow,...
                                             'Label','Closest Points...',...
                                             'Separator','off',...
                                             'Enable','off',...
                                             'Callback',@HideShowClosest_callback);
                                         
            % View->Inspect... Menu                 
            GUI.hMenu_view_inspect = uimenu('Parent',GUI.hMenu_view,...
                                             'Label','Property Inspector...',...
                                             'Separator','on',...
                                             'Enable','on',...
                                             'Callback',@ViewInspect_callback);
    end %MenuBar

%--------------------------------------------------------------------------
% ToolBar Objects
%--------------------------------------------------------------------------

    function ToolBar(hFigure)
        % Create ToolBar
        GUI.hToolBar = uitoolbar(hFigure);
             % PushTool->Open...
             GUI.hPushtool_open = uipushtool('Parent',GUI.hToolBar,...
                                             'Cdata',iconRead('icons/folderopen.gif'),...
                                             'ClickedCallback',@LoadSTL_callback,...
                                             'ToolTipString','Load an STL object from an ascii file.',...
                                             'Enable','on');
    end %ToolBar

%--------------------------------------------------------------------------
% MenuBar and ToolBar Callbacks
%--------------------------------------------------------------------------

    function FileSetPath_callback(hObject,eventdata)
        [PathName] = uigetdir(GUI.pathname);
        if PathName ~= 0
            GUI.pathname = PathName;
        end
    end

    function FilePreferences_callback(hObject,eventdata)
        [settings button] = settingsdlg(...
                                        'WindowWidth',300,...
                                        'title','Preferences',...
                                        'separator','Export Settings',...
                                        {'Closest/Contact Points Reference','PTSMETHOD'},{'Model','Global'},...
                                        'separator','Graphics Display Settings',...
                                        'Shading',{'Flat','Phong'},...
                                        'separator','Other Settings');

        switch button
            case 'ok'
                if strcmp(settings.PTSMETHOD,'Model')
                    GUI.ptsmethod = 1;
                else
                    GUI.ptsmethod = 0;
                end
            case 'cancel'
                
        end
    end

    % Save model as matlab format
    function SaveModelAs_callback(hObject,eventdata)
        SaveModelAs_tool(GUI)
    end

    % Save region as matlab format
    function SaveRegionAs_callback(hObject,eventdata)
        SaveRegionAs_tool(GUI)
    end

    % Save closest points
    function SaveClosestAs_callback(hObject,eventdata)
        % Get save filename
        [FileName PathName isok] = uiputfile('points.txt','Save closest points...',GUI.pathname);
        if isok
            M = zeros(GUI.num_kin,3*length(GUI.hClosestpt));
            header = cell(1,length(GUI.Dmap));
            mheader = cell(1,2*length(GUI.Dmap));
            cheader = zeros(6*length(GUI.Dmap),1);
            for i = 1:length(GUI.Dmap)
                mdata1 = get(GUI.hPatch{GUI.Dmap{i}.modelid(1)},'UserData');
                mdata2 = get(GUI.hPatch{GUI.Dmap{i}.modelid(2)},'UserData');
                for j = 1:GUI.num_kin
                    if GUI.ptsmethod == 0 % GLOBAL reference
                        data3 = mdata1.tform{j}*[GUI.Region.v{GUI.Dmap{i}.regionid(1)}(GUI.Dmap{i}.closestpt{j}(1),1:3) 1]';
                        data4 = mdata2.tform{j}*[GUI.Region.v{GUI.Dmap{i}.regionid(2)}(GUI.Dmap{i}.closestpt{j}(2),1:3) 1]';
                    else % MODEL reference
                        data3 = [GUI.Region.v{GUI.Dmap{i}.regionid(1)}(GUI.Dmap{i}.closestpt{j}(1),1:3) 1]';
                        data4 = [GUI.Region.v{GUI.Dmap{i}.regionid(2)}(GUI.Dmap{i}.closestpt{j}(2),1:3) 1]';
                    end
                    %M(j,(6*i-5):(6*i)) = [GUI.Region.v{GUI.Dmap{i}.regionid(1)}(GUI.Dmap{i}.closestpt{j}(1),1:3), GUI.Region.v{GUI.Dmap{i}.regionid(2)}(GUI.Dmap{i}.closestpt{j}(2),1:3)];
                    M(j,(6*i-5):(6*i)) = [data3(1:3)' data4(1:3)'];
                end
                header{i} = ['Closest Point ' num2str(i)];
                mheader{2*i-1} = mdata1.name;
                mheader{2*i} = mdata2.name;
                cheader((6*i-5):(6*i),1) = ['x';'y';'z';'x';'y';'z'];
            end
            fid = fopen(fullfile(PathName,FileName),'w');
            fprintf(fid,'%s\t\t\t\t\t\t',header{:}); fprintf(fid,'\n');
            fprintf(fid,'%s\t\t\t',mheader{:}); fprintf(fid,'\n');
            fprintf(fid,'%c\t',cheader); fprintf(fid,'\n');
            fclose(fid);
            dlmwrite(fullfile(PathName,FileName), M,'-append','delimiter','\t','precision','%10.4f')
            set(GUI.hStatusbar,'String','Saving closest points...completed.')
            
        else
            set(GUI.hStatusbar,'String','Saving closest points...canceled.')
        end
    end

    % Save contact points
    function SaveContactAs_callback(hObject,eventdata)
        % Get save filename
        [FileName PathName isok] = uiputfile('points.txt','Save contact points...',GUI.pathname);
        if isok
            M = zeros(GUI.num_kin,3*length(GUI.hContactpt));
            header = cell(1,length(GUI.Dmap));
            mheader = cell(1,2*length(GUI.Dmap));
            cheader = zeros(6*length(GUI.Dmap),1);
            for i = 1:length(GUI.Dmap)
                mdata1 = get(GUI.hPatch{GUI.Dmap{i}.modelid(1)},'UserData');
                mdata2 = get(GUI.hPatch{GUI.Dmap{i}.modelid(2)},'UserData');
                for j = 1:GUI.num_kin
                    
                    if GUI.ptsmethod == 0; % GLOBAL reference
                    % Transformed data
                        data3 = mdata1.tform{j}*[GUI.Region.v{GUI.Dmap{i}.regionid(1)}(GUI.Dmap{i}.contactpt{j}(1),1:3) 1]';
                        data4 = mdata2.tform{j}*[GUI.Region.v{GUI.Dmap{i}.regionid(2)}(GUI.Dmap{i}.contactpt{j}(2),1:3) 1]';
                    %data3 = [GUI.Region.v{GUI.Dmap{i}.regionid(1)}(GUI.Dmap{i}.contactpt{j}(1),1:3) 1]';
                    %data4 = [GUI.Region.v{GUI.Dmap{i}.regionid(2)}(GUI.Dmap{i}.contactpt{j}(2),1:3) 1]';
                    else % MODEL reference
                        data3 = [GUI.Dmap{i}.contactpt{j}(1,1),GUI.Dmap{i}.contactpt{j}(1,2),GUI.Dmap{i}.contactpt{j}(1,3)]';
                        data4 = [GUI.Dmap{i}.contactpt{j}(2,1),GUI.Dmap{i}.contactpt{j}(2,2),GUI.Dmap{i}.contactpt{j}(2,3)]';
                    end
                    
                    M(j,(6*i-5):(6*i)) = [data3(1:3)' data4(1:3)'];
                    
                    % Point on model data
                    %M(j,(6*i-5):(6*i)) = [GUI.Dmap{i}.contactpt{j}(1,1:3), GUI.Dmap{i}.contactpt{j}(2,1:3)];

                end
                header{i} = ['Contact Point ' num2str(i)];
                mheader{2*i-1} = mdata1.name;
                mheader{2*i} = mdata2.name;
                cheader((6*i-5):(6*i),1) = ['x';'y';'z';'x';'y';'z'];
            end
            fid = fopen(fullfile(PathName,FileName),'w');
            fprintf(fid,'%s\t\t\t\t\t\t',header{:}); fprintf(fid,'\n');
            fprintf(fid,'%s\t\t\t',mheader{:}); fprintf(fid,'\n');
            fprintf(fid,'%c\t',cheader); fprintf(fid,'\n');
            fclose(fid);
            dlmwrite(fullfile(PathName,FileName), M,'-append','delimiter','\t','precision','%10.4f')
            set(GUI.hStatusbar,'String','Saving contact points...completed.')
            
        else
            set(GUI.hStatusbar,'String','Saving contact points...canceled.')
        end
    end

    % Make movie
    function SaveMovieAs_callback(hobject,eventdata)
        % Get save filename
        [FileName PathName isok] = uiputfile('movie.avi');
        if isok
            %GUI.L = [];
            % Get screen size
            scrnsz = get(GUI.hFigure,'position');
            for i = 1:GUI.num_kin
                % Set frame and update display
                set(GUI.hSlider,'Value',i);
                UI_Slider(GUI.hSlider,0)
                % Collect frame
                GUI.P(i) = getframe(GUI.hAxes,[0 32 scrnsz(3) scrnsz(4)-32]);
            end
            % Update status bar
            set(GUI.hStatusbar,'String','Saving movie...')
            % Write movie file
            movie2avi(GUI.P,fullfile(PathName,FileName),'fps',7,'compression','none');
            % Update status bar
            set(GUI.hStatusbar,'String','Saving movie...completed.')
        else
            set(GUI.hStatusbar,'String','Saving movie...canceled.')
        end
        guidata(GUI.hFigure,GUI)
    end

    % LoadSTL_callback
    function LoadSTLModelascii_callback(hObject, eventdata)
        
        % Open standard dialog for retrieving files
        [FileName,PathName,isok] = uigetfile('*.stl','Load ASCII Model...',GUI.pathname);
        % Update statusbar
        set(GUI.hStatusbar,'String','Loading ascii stl file...'); drawnow;
        
        % Check if file path is valid
        if ~isok
            
            % Update statusbar
            set(GUI.hStatusbar,'String','Loading ascii stl file...canceled.'); drawnow;
        else
            GUI.pathname = PathName;
            
            % Import STL data
            [v,f,n] = stla_read_fast(fullfile(PathName,FileName));
            
            % Remove duplicate vertices
            [v,f]=patchslim(v', f');
            
            % Create transform object
            GUI.hTform{length(GUI.hTform)+1} = hgtransform('Parent',GUI.hAxes);
            
            % Create patch object
            GUI.hPatch{length(GUI.hPatch)+1} = create_patch(GUI.hTform{length(GUI.hTform)},f,v,[179/256 179/256 179/256],0.99);
            
            % Create patch UserData structure
            userdata = struct('name',FileName,'tform',{{}});
            set(GUI.hPatch{length(GUI.hPatch)},'UserData',userdata)
            
            % Enable tools
            set(GUI.hMenu_file_savemodel,'Enable','on')
            set(GUI.hMenu_file_open_matlabregion,'Enable','on')
            set(GUI.hMenu_tools_transform,'Enable','on')
            set(GUI.hMenu_tools_createregion,'Enable','on')
            set(GUI.hMenu_tools_joint,'Enable','on')
            set(GUI.hMenu_tools_joint_knee,'Enable','on')
            set(GUI.hMenu_tools_joint_knee_cor,'Enable','on')
            set(GUI.hMenu_tools_joint_knee_kin,'Enable','on')
            
            % Update statusbar
            set(GUI.hStatusbar,'String','Loading ascii stl file...completed.'); drawnow;

        end %if
        
        guidata(GUI.hFigure,GUI)
        
    end %LoadSTL_callback

  % LoadSTLbinary_callback
    function LoadSTLModelbinary_callback(hObject, eventdata)
        
        % Open standard dialog for retrieving files
        [FileName,PathName,isok] = uigetfile('*.stl','Load Binary model...',GUI.pathname);
        
        % Update statusbar
        set(GUI.hStatusbar,'String','Loading binary stl file...'); drawnow;
        
        % Check if file path is valid
        if ~isok
            % Update statusbar
            set(GUI.hStatusbar,'String','Loading binary stl file...canceled.'); drawnow;
        else
            GUI.pathname = PathName;
            
            % Import STL data
            [v,f,n] = stlb_read_fast(fullfile(PathName,FileName));
            
            % Remove duplicate vertices
            [v,f]=patchslim(v, f);
            
            % Create transform object
            GUI.hTform{length(GUI.hTform)+1} = hgtransform('Parent',GUI.hAxes);
            
            % Create patch object
            % Added in for Dr. Banks: Color Variance
            if GUI.FunColor == 0
                GUI.hPatch{length(GUI.hPatch)+1} = create_patch(GUI.hTform{length(GUI.hTform)},f,v,[255/256 165/256 0/256],0.99);
            else
                GUI.hPatch{length(GUI.hPatch)+1} = create_patch(GUI.hTform{length(GUI.hTform)},f,v,[0/256 0/256 255/256],0.99);
            end
            GUI.FunColor = 1;
            
            % Create patch UserData structure
            userdata = struct('name',FileName,'tform',{{}});
            set(GUI.hPatch{length(GUI.hPatch)},'UserData',userdata)
            
            % Enable Transform tool
            set(GUI.hMenu_file_savemodel,'Enable','on')
            set(GUI.hMenu_file_open_matlabregion,'Enable','on')
            set(GUI.hMenu_tools_transform,'Enable','on')
            set(GUI.hMenu_tools_createregion,'Enable','on')
            set(GUI.hMenu_tools_joint,'Enable','on')
            set(GUI.hMenu_tools_joint_knee,'Enable','on')
            set(GUI.hMenu_tools_joint_knee_cor,'Enable','on')
            set(GUI.hMenu_tools_joint_knee_kin,'Enable','on')
            
            % Update statusbar
            set(GUI.hStatusbar,'String','Loading binary stl file...completed.'); drawnow;

        end %if
        
        guidata(GUI.hFigure,GUI)
        
    end %LoadSTL_callback

    % Load Matlab Model Callback
    function LoadMATLABModel_callback(hObject,eventdata)
        
        % Update statusbar
        set(GUI.hStatusbar,'String','Loading MATLAB Model file...'); drawnow;
        
        [FileName,PathName,isok] = uigetfile('*.model','Load Matlab model...',GUI.pathname);
        
        if isok
            GUI.pathname = PathName;
            data = importdata(fullfile(PathName,FileName));
            
            % Create transform object
            GUI.hTform{length(GUI.hTform)+1} = hgtransform('Parent',GUI.hAxes);
            
            % Create patch object
            GUI.hPatch{length(GUI.hPatch)+1} = create_patch(GUI.hTform{length(GUI.hTform)},data.properties.Faces,data.properties.Vertices,[179/256 179/256 179/256],0.99);
            
            % Create patch UserData structure
            userdata = struct('name',FileName,'tform',{{}});
            set(GUI.hPatch{length(GUI.hPatch)},'UserData',userdata)
            
            % Enable Transform tool
            set(GUI.hMenu_file_savemodel,'Enable','on')
            set(GUI.hMenu_tools_transform,'Enable','on')
            set(GUI.hMenu_tools_createregion,'Enable','on')
            set(GUI.hMenu_file_open_matlabregion,'Enable','on')
            set(GUI.hMenu_tools_joint,'Enable','on')
            set(GUI.hMenu_tools_joint_knee,'Enable','on')
            set(GUI.hMenu_tools_joint_knee_cor,'Enable','on')
            set(GUI.hMenu_tools_joint_knee_kin,'Enable','on')
            
            % Update statusbar
            set(GUI.hStatusbar,'String','Loading MATLAB Model file...completed.'); drawnow;
            
        else
            % Update statusbar
            set(GUI.hStatusbar,'String','Loading MATLAB Model file...canceled.'); drawnow;
        end
        
    end

    % Transform_callback
    function Transform_callback(hObject, eventdata)

        LoadTransform_tool(GUI); uiwait;
        GUI = guidata(GUI.hFigure);
        GUI.frame = 1;
        if GUI.num_kin > 1
            set(GUI.hSlider,'Enable','on')
            set(GUI.hSlider,'Max',GUI.num_kin)
            set(GUI.hSlider,'SliderStep',[1/(GUI.num_kin-1) 5/(GUI.num_kin-1)])
            set(GUI.hSlider,'Value',1)
            set(GUI.hMenu_file_savemovie,'Enable','on')
            UI_Slider(GUI.hSlider,0)
            set(GUI.hStatusbar,'String','Transformation completed.')
        else
            set(GUI.hStatusbar,'String','Transformation canceled.')
        end
        
        guidata(GUI.hFigure,GUI)
        
    end %Transform_callback

    function CreateRegion_callback(hObject,eventdata)

        RegionSelect_tool(GUI); uiwait;
        GUI = guidata(GUI.hFigure);
        %set(GUI.hRegion{length(GUI.hRegion)},'Parent',GUI.hTform{1}); drawnow;
        guidata(GUI.hFigure,GUI)
        
        set(GUI.hMenu_view_hideshow_regions,'Enable','on')
        set(GUI.hMenu_file_saveregion,'Enable','on')
        
        % Turn options on
        if length(GUI.hRegion) >=2
            set(GUI.hMenu_tools_nearestneighbour,'Enable','on')
        end
                    

    end

    function LoadMATLABRegion_callback(hObject,eventdata)
        % Update statusbar
        set(GUI.hStatusbar,'String','Loading MATLAB Region file...'); drawnow;
        
        LoadRegion_tool(GUI); uiwait;
        GUI = guidata(GUI.hFigure);
        guidata(GUI.hFigure,GUI)
        
        
        set(GUI.hMenu_view_hideshow_regions,'Enable','on')
        set(GUI.hMenu_file_saveregion,'Enable','on')
        
        % Turn options on
        if length(GUI.hRegion) >=2
            set(GUI.hMenu_tools_nearestneighbour,'Enable','on')
        end
    end

    function NearestNeighbour_callback(hObject,eventdata)
        
        % Update statusbar
        set(GUI.hStatusbar,'String','Calculating nearest neighbor...'); drawnow;

        NearestNeighbour_tool(GUI); uiwait;
        %NearestNeighbour_tool_FV(GUI); uiwait;
        
        GUI = guidata(GUI.hFigure);

        if length(GUI.hClosestpt) >= 2
        GUI.hAxes; hold on;

        % Turn point view option on
        set(GUI.hMenu_view_hideshow_closest,'Enable','on')
        set(GUI.hMenu_file_saveclosest,'Enable','on')
        set(GUI.hMenu_file_savecontact,'Enable','on')
        
        guidata(GUI.hFigure,GUI)

        % Update statusbar
        set(GUI.hStatusbar,'String','Calculating nearest neighbour...completed'); drawnow;
        else
        % Update statusbar
        set(GUI.hStatusbar,'String','Calculating nearest neighbour...canceled'); drawnow;
        end

        UI_Slider(GUI.hSlider,0)
    end

    function KneeCORplot_callback(hObject,eventdata)
        KneeCORplot_tool(GUI);
    end

    function KneeSaveKin_callback(hObject,eventdata)
        KneeSaveKin_tool(GUI); uiwait;
    end

    % View regions switch
    function HideShowRegions_callback(hObject,eventdata)
        for i = 1:length(GUI.hRegion)
        visible = get(GUI.hRegion{i},'Visible');
            switch visible
                case 'on'
                    set(GUI.hRegion{i},'Visible','off')
                case 'off'
                    set(GUI.hRegion{i},'Visible','on')
            end
        end
    end

    % View closest points switch
    function HideShowClosest_callback(hObject,eventdata)
        for i = 1:length(GUI.hClosestpt)
        visible = get(GUI.hClosestpt{i},'Visible');
            switch visible
                case 'on'
                    set(GUI.hClosestpt{i},'Visible','off')

                case 'off'
                    set(GUI.hClosestpt{i},'Visible','on')
            end
        end
    end

    % View Property Inspector 
    function ViewInspect_callback(hObject,eventdata)
         inspect(gco)
    end

%--------------------------------------------------------------------------
% UIControl Callbacks
%--------------------------------------------------------------------------

    function UI_Slider(hObject,eventdata)

        GUI.frame = round(get(hObject,'Value'));
        set(hObject,'Value',GUI.frame)

        tempdata = get(GUI.hPatch{length(GUI.hPatch)},'UserData');
        refdata = tempdata.tform;
        
        for i = 1:length(GUI.hPatch)
            % Get transform data
            data = get(GUI.hPatch{i},'UserData');
            
            if length(data.tform) >= GUI.frame
                if length(refdata) >= GUI.frame
                    set(GUI.hTform{i},'Matrix',inv(refdata{GUI.frame})*data.tform{GUI.frame})
                else
                    set(GUI.hTform{i},'Matrix',data.tform{GUI.frame})
                end
            end
                
            % Set new hgtransform matrix

        end
        
        % Update point graphic objects
        for i = 1:length(GUI.Dmap)

            % Delete previous points
            %delete(GUI.hClosestpt{2*i-1}); delete(GUI.hClosestpt{2*i});
            %delete(GUI.hContactpt{2*i-1}); delete(GUI.hContactpt{2*i});

        end

        for i = 1:length(GUI.Dmap)
            % Create closest point graphic objects
            %GUI.hClosestpt{2*i-1} = drawSphere(GUI.Region.v{GUI.Dmap{i}.regionid(1)}(GUI.Dmap{i}.closestpt{GUI.frame}(1),1),...
                                                   %GUI.Region.v{GUI.Dmap{i}.regionid(1)}(GUI.Dmap{i}.closestpt{GUI.frame}(1),2),...
                                                   %GUI.Region.v{GUI.Dmap{i}.regionid(1)}(GUI.Dmap{i}.closestpt{GUI.frame}(1),3),0.75,'Parent',GUI.hTform{GUI.Dmap{i}.modelid(1)},'FaceColor','b','EdgeColor','none');

            %GUI.hClosestpt{2*i} = drawSphere(GUI.Region.v{GUI.Dmap{i}.regionid(2)}(GUI.Dmap{i}.closestpt{GUI.frame}(2),1),...
                                                   %GUI.Region.v{GUI.Dmap{i}.regionid(2)}(GUI.Dmap{i}.closestpt{GUI.frame}(2),2),...
                                                   %GUI.Region.v{GUI.Dmap{i}.regionid(2)}(GUI.Dmap{i}.closestpt{GUI.frame}(2),3),0.75,'Parent',GUI.hTform{GUI.Dmap{i}.modelid(2)},'FaceColor','b','EdgeColor','none');

            % Create contact point graphic objects
            GUI.hContactpt{2*i-1} = drawSphere(GUI.Dmap{i}.contactpt{GUI.frame}(1,1),GUI.Dmap{i}.contactpt{GUI.frame}(1,2),GUI.Dmap{i}.contactpt{GUI.frame}(1,3),0.75,'Parent',GUI.hTform{GUI.Dmap{i}.modelid(1)},'FaceColor','k','EdgeColor','none');
            %GUI.hContactpt{2*i-1} = copyobj(GUI.hContactpt{length(GUI.hContactpt)},GUI.hTform{GUI.Dmap{length(GUI.Dmap)}.modelid(1)});

            GUI.hContactpt{2*i} = drawSphere(GUI.Dmap{i}.contactpt{GUI.frame}(2,1),GUI.Dmap{i}.contactpt{GUI.frame}(2,2),GUI.Dmap{i}.contactpt{GUI.frame}(2,3),0.75,'Parent',GUI.hTform{GUI.Dmap{i}.modelid(2)},'FaceColor','k','EdgeColor','none');
            %GUI.hContactpt{length(GUI.hContactpt)} = copyobj(GUI.hContactpt{length(GUI.hContactpt)},GUI.hTform{GUI.Dmap{length(GUI.Dmap)}.modelid(2)});


            % First point
            %set(GUI.hClosestpt{2*i-1},'XData',GUI.Region.v{GUI.Dmap{i}.regionid(1)}(GUI.Dmap{i}.closestpt{GUI.frame}(1),1))
            %set(GUI.hClosestpt{2*i-1},'YData',GUI.Region.v{GUI.Dmap{i}.regionid(1)}(GUI.Dmap{i}.closestpt{GUI.frame}(1),2))
            %set(GUI.hClosestpt{2*i-1},'ZData',GUI.Region.v{GUI.Dmap{i}.regionid(1)}(GUI.Dmap{i}.closestpt{GUI.frame}(1),3))
            
            % Second point
            %set(GUI.hClosestpt{2*i},'XData',GUI.Region.v{GUI.Dmap{i}.regionid(2)}(GUI.Dmap{i}.closestpt{GUI.frame}(2),1))
            %set(GUI.hClosestpt{2*i},'YData',GUI.Region.v{GUI.Dmap{i}.regionid(2)}(GUI.Dmap{i}.closestpt{GUI.frame}(2),2))
            %set(GUI.hClosestpt{2*i},'ZData',GUI.Region.v{GUI.Dmap{i}.regionid(2)}(GUI.Dmap{i}.closestpt{GUI.frame}(2),3))
            
        end
        
        % Update distance map colors
        %color_update('interp')
        color_update('flat')

        if length(refdata) >= GUI.frame
            % Update camera position
            %set(GUI.hAxes,'CameraTarget',[refdata.tform{GUI.frame}(1,4),refdata.tform{GUI.frame}(2,4),refdata.tform{GUI.frame}(3,4)])
            %set(GUI.hAxes,'CameraTarget',[0 0 0])
            set(GUI.hAxes,'CameraViewAngleMode','manual',...
                          'CameraPositionMode','manual',...
                          'CameraTargetMode','manual',...
                          'CameraUpVectorMode','manual',...
                          'CameraViewAngleMode','manual');
            
        end
        
        % Update statusbar
        set(GUI.hStatusbar,'String',['Current frame: ' num2str(GUI.frame) '/' num2str(GUI.num_kin)])

    end

%--------------------------------------------------------------------------
% Other Callbacks
%--------------------------------------------------------------------------

    function hFigure_resize(hObject,eventdata)
        
        % Get screen size
        pos = get(hObject,'Position');
        
        % Adjust Panel and Statusbar position
        set(GUI.hPanel,'Position',[0 0 pos(3) 18]);
        set(GUI.hStatusbar,'Position',[0 0 pos(3) 12]);
        set(GUI.hSlider,'Position',[0 12 pos(3) 20]);
    end

    function axes_buttondown(hObject,eventdata)
%         disp('called')
%         for i = 1:length(GUI.hPatch)
%             set(GUI.hPatch{i},'FaceAlpha',0.99)
%         end%for
%         drawnow;
    end

    function patch_buttondown(hObject,eventdata)
%         for i = 1:length(GUI.hPatch)
%             if GUI.hPatch{i} == hObject
%                 set(GUI.hPatch{i},'FaceAlpha',0.99)
%             else
%                 set(GUI.hPatch{i},'FaceAlpha',0.5)
%             end%if
%             drawnow;
%         end%for
    end

%--------------------------------------------------------------------------
% GUI Utilities
%--------------------------------------------------------------------------

    function hPatch = create_patch(hAxes,f,v,color,alpha)
    
        % Create Patch Object
        hPatch = patch('Parent',hAxes,...            % Set the parent axes
                       'faces', f,...             % Add faces to patch
                       'vertices',v,...           % Add vertices to patch
                       'FaceColor',color,...         % Set the face color
                       'FaceAlpha',alpha,...         % Set the transparency value
                       'EdgeColor', 'none',...       % Set the edge color
                       'FaceLighting','gouraud',...  % Set face lighting metric
                       ...%'ButtonDownFcn',@patch_buttondown,...
                       'SelectionHighlight','off',...
                       'HitTest','on',...
                       'Visible','on');              % Set visibility to off
        
    end %create_patch

    function color_update(faceoption)
        for i = 1:length(GUI.Dmap)

            % Model 1 color
            
            cdata = zeros(length(get(GUI.hPatch{GUI.Dmap{i}.modelid(1)},'Vertices')),3);
            
                for j = 1:length(GUI.Region.v{GUI.Dmap{i}.regionid(1)})
                    cdata(GUI.Region.vid{GUI.Dmap{i}.regionid(1)}(j),1:3) = GUI.Dmap{i}.color1{GUI.frame}(j,1:3);
                end

            % interp or flat
            set(GUI.hPatch{GUI.Dmap{i}.modelid(1)},'FaceVertexCData',cdata,'FaceColor',faceoption)
            
           % Model 2 color

            cdata = zeros(length(get(GUI.hPatch{GUI.Dmap{i}.modelid(2)},'Vertices')),3);
            
                for j = 1:length(GUI.Region.v{GUI.Dmap{i}.regionid(2)})
                    cdata(GUI.Region.vid{GUI.Dmap{i}.regionid(2)}(j),1:3) = GUI.Dmap{i}.color2{GUI.frame}(j,1:3);
                end
            
            set(GUI.hPatch{GUI.Dmap{i}.modelid(2)},'FaceVertexCData',cdata,'FaceColor',faceoption)
            
        end
    end

end %GUI_MainWindow 
